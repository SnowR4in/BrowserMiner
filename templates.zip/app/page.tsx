"use client"

import  from "../static/js/captcha-reload"

export default function SyntheticV0PageForDeployment() {
  return < />
}