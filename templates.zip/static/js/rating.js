document.addEventListener("DOMContentLoaded", () => {
  // Handle rating buttons
  const ratingButtons = document.querySelectorAll(".rating-btn")

  ratingButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const rating = this.getAttribute("data-rating")
      const documentId = this.getAttribute("data-key")

      fetch("/rate/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRFToken": getCookie("csrf_token"),
        },
        body: JSON.stringify({
          document_id: documentId,
          rating: rating,
        }),
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            // Update UI
            const likeCount = document.querySelector(`.thumbs-up[data-key="${documentId}"] .like-count`)
            const dislikeCount = document.querySelector(`.thumbs-down[data-key="${documentId}"] .dislike-count`)

            if (likeCount) likeCount.textContent = data.likes
            if (dislikeCount) dislikeCount.textContent = data.dislikes

            // Update button styles
            const thumbsUp = document.querySelector(`.thumbs-up[data-key="${documentId}"]`)
            const thumbsDown = document.querySelector(`.thumbs-down[data-key="${documentId}"]`)

            if (rating === "1") {
              thumbsUp.classList.remove("btn-outline-secondary")
              thumbsUp.classList.add("btn-success")
              thumbsDown.classList.remove("btn-danger")
              thumbsDown.classList.add("btn-outline-secondary")
            } else {
              thumbsDown.classList.remove("btn-outline-secondary")
              thumbsDown.classList.add("btn-danger")
              thumbsUp.classList.remove("btn-success")
              thumbsUp.classList.add("btn-outline-secondary")
            }
          }
        })
        .catch((error) => console.error("Error:", error))
    })
  })

  // Helper function to get CSRF token from cookies
  function getCookie(name) {
    let cookieValue = null
    if (document.cookie && document.cookie !== "") {
      const cookies = document.cookie.split(";")
      for (let i = 0; i < cookies.length; i++) {
        const cookie = cookies[i].trim()
        if (cookie.substring(0, name.length + 1) === name + "=") {
          cookieValue = decodeURIComponent(cookie.substring(name.length + 1))
          break
        }
      }
    }
    return cookieValue
  }
})
