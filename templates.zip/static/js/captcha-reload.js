document.addEventListener("DOMContentLoaded", () => {
  // Handle captcha reload
  const captchaReload = document.querySelector(".captcha-reload")
  if (captchaReload) {
    captchaReload.addEventListener("click", () => {
      const captchaImage = document.querySelector(".captcha-image")
      if (captchaImage) {
        // Add timestamp to prevent caching
        captchaImage.src = captchaImage.src.split("?")[0] + "?" + new Date().getTime()
      }
    })
  }
})
