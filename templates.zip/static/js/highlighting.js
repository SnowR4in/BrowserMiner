document.addEventListener("DOMContentLoaded", () => {
  // Initialize CodeMirror with green theme
  var editor = CodeMirror.fromTextArea(document.querySelector(".codemirror-textarea"), {
    lineNumbers: true,
    mode: "text/plain",
    theme: "material-darker",
    lineWrapping: true,
    indentUnit: 4,
    tabSize: 4,
    indentWithTabs: true,
    extraKeys: { Tab: "indentMore", "Shift-Tab": "indentLess" },
  })

  // Toggle syntax highlighting
  var toggleSwitch = document.getElementById("onoff")
  if (toggleSwitch) {
    toggleSwitch.addEventListener("change", function () {
      if (this.checked) {
        editor.setOption("mode", "javascript")
        this.value = "on"
      } else {
        editor.setOption("mode", "text/plain")
        this.value = "off"
      }
    })
  }

  // Set syntax based on selected language
  var syntaxSelect = document.querySelector('select[name="syntax"]')
  if (syntaxSelect) {
    syntaxSelect.addEventListener("change", function () {
      var syntax = this.value
      switch (syntax) {
        case "javascript":
        case "js":
          editor.setOption("mode", "javascript")
          break
        case "python":
          editor.setOption("mode", "python")
          break
        case "html":
          editor.setOption("mode", "htmlmixed")
          break
        case "css":
          editor.setOption("mode", "css")
          break
        case "sql":
          editor.setOption("mode", "sql")
          break
        default:
          editor.setOption("mode", "text/plain")
      }
    })
  }
})
