document.addEventListener("DOMContentLoaded", () => {
  // Handle reply buttons
  const replyButtons = document.querySelectorAll(".reply-btn")

  replyButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const commentId = this.getAttribute("id")
      const replyContainer = document.querySelector(`.reply-form-container-${commentId}`)

      if (replyContainer.innerHTML.trim() === "") {
        // Create reply form
        fetch(`/reply-form/${commentId}/`)
          .then((response) => response.text())
          .then((html) => {
            replyContainer.innerHTML = html

            // Add event listener to the new form
            const form = replyContainer.querySelector("form")
            form.addEventListener("submit", (e) => {
              e.preventDefault()

              const formData = new FormData(form)

              fetch(form.action, {
                method: "POST",
                body: formData,
              })
                .then((response) => response.json())
                .then((data) => {
                  if (data.success) {
                    // Reload the page to show the new reply
                    window.location.reload()
                  } else {
                    alert("Error posting reply: " + data.message)
                  }
                })
                .catch((error) => console.error("Error:", error))
            })
          })
          .catch((error) => console.error("Error:", error))
      } else {
        // Toggle form visibility
        replyContainer.innerHTML = ""
      }
    })
  })

  // Handle captcha reload
  const captchaReload = document.querySelector(".captcha-reload")
  if (captchaReload) {
    captchaReload.addEventListener("click", () => {
      const captchaImage = document.querySelector(".captcha-image")
      if (captchaImage) {
        // Add timestamp to prevent caching
        captchaImage.src = captchaImage.src.split("?")[0] + "?" + new Date().getTime()
      }
    })
  }
})
